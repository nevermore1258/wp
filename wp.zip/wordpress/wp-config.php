<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'remoteuser' );

/** MySQL database password */
define( 'DB_PASSWORD', 'password' );

/** MySQL hostname */
define( 'DB_HOST', '157.230.39.130' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

define('MYSQL_CLIENT_FLAGS', MYSQLI_CLIENT_SSL);
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */

define('AUTH_KEY',         '^}yZx)LQj3k;X;%W`tb*SYzRar,F*<l|){[AT0nCo@!hw WrR&@m3:&EuiNj*ALb');
define('SECURE_AUTH_KEY',  'n{=|k9#.0HYtd|M&A_0=^k?vqPi&#?Kj$jP v.u;f&{;#epSV}[!Hss[8e}MP=#g');
define('LOGGED_IN_KEY',    '{jH@eP}|CLW ->A??vkEii=^B`b.}rM=/$SA$XEjOt+B/ /gk,^7`Xy}1 t p#(|');
define('NONCE_KEY',        '-KI[UM]/ !lIHhQ(lhvU+Le~m-R8_Sux2uxgr)JD(|kZ!?,/y/2C|NwB|4C}`1k<');
define('AUTH_SALT',        '=hK)6Ab+gmJ;g~}>+sQJDM-A7UN|NpDI5o@`8 UM-6$g0C|5U,% w.LfG4gxCG*o');
define('SECURE_AUTH_SALT', '&Zr@Prdi%Y4(#>4)tHoyBEd.YZqR!3uJB.P;!qIJ1C+IPbmULDI>D?9=+F-m Pft');
define('LOGGED_IN_SALT',   'c?Vbg@*B2XUS5`x-Yx%_7 m)gll%/-1wEyBde{?Lp+*gTJeGC==u@e|K%Nhe+KBH');
define('NONCE_SALT',       '@FX$,u#]K-ycEAq{7)N3zXcAVw|+@$mGRCQ}ha>}s>iNx=o>pR&T!nK?@hM@?oQa');


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
